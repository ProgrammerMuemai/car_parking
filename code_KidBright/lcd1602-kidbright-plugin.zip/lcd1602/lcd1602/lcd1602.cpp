#ifndef __LCD1602_CPP__
#define __LCD1602_CPP__

#include <stdio.h>
#include <string.h>
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "rom/ets_sys.h"
#include "kidbright32.h"
#include "lcd1602.h"

// Common PCF8574 backpack mapping:
// P0=RS, P1=RW, P2=EN, P3=Backlight, P4..P7=D4..D7
#define LCD_RS 0x01
#define LCD_EN 0x04
#define LCD_BACKLIGHT 0x08

LCD1602::LCD1602(int bus_ch, int dev_addr) {
  channel = bus_ch;
  address = dev_addr;
  bus = NULL;
  backlightMask = LCD_BACKLIGHT;
  lcdReady = false;
}

void LCD1602::init(void) {
  bus = NULL;
  backlightMask = LCD_BACKLIGHT;
  lcdReady = false;
  initialized = false;
  error = false;
}

int LCD1602::prop_count(void) { return 0; }
bool LCD1602::prop_name(int index, char *name) { return false; }
bool LCD1602::prop_unit(int index, char *unit) { return false; }
bool LCD1602::prop_attr(int index, char *attr) { return false; }
bool LCD1602::prop_read(int index, char *value) { return false; }
bool LCD1602::prop_write(int index, char *value) { return false; }

void LCD1602::process(Driver *drv) {
  bus = (I2CDev *)drv;
  if (!initialized && bus != NULL) {
    if (bus->detect(channel, address) == ESP_OK) {
      initialized = true;
      error = false;
    } else {
      error = true;
    }
  }
}

void LCD1602::delayMs(uint32_t ms) {
  TickType_t ticks = ms / portTICK_PERIOD_MS;
  if (ticks < 1) ticks = 1;
  vTaskDelay(ticks);
}

bool LCD1602::waitForBus(uint32_t timeoutMs) {
  uint32_t waited = 0;
  while (bus == NULL && waited < timeoutMs) {
    delayMs(10);
    waited += 10;
  }
  if (bus == NULL) {
    error = true;
    return false;
  }
  if (bus->detect(channel, address) != ESP_OK) {
    error = true;
    initialized = false;
    return false;
  }
  initialized = true;
  error = false;
  return true;
}

bool LCD1602::writeExpander(uint8_t value) {
  if (bus == NULL && !waitForBus()) return false;
  uint8_t data = value | backlightMask;
  esp_err_t result = bus->write(channel, address, &data, 1);
  if (result != ESP_OK) {
    error = true;
    return false;
  }
  error = false;
  return true;
}

void LCD1602::pulseEnable(uint8_t value) {
  writeExpander(value | LCD_EN);
  ets_delay_us(1);
  writeExpander(value & ~LCD_EN);
  ets_delay_us(50);
}

void LCD1602::write4Bits(uint8_t value) {
  writeExpander(value);
  pulseEnable(value);
}

void LCD1602::send(uint8_t value, uint8_t mode) {
  uint8_t high = (value & 0xF0) | mode;
  uint8_t low = ((value << 4) & 0xF0) | mode;
  write4Bits(high);
  write4Bits(low);
}

void LCD1602::command(uint8_t value) {
  send(value, 0);
}

void LCD1602::writeChar(uint8_t value) {
  send(value, LCD_RS);
}

void LCD1602::begin(int backlightOn) {
  if (!waitForBus()) return;
  backlightMask = backlightOn ? LCD_BACKLIGHT : 0;

  // HD44780 4-bit initialization sequence.
  delayMs(50);
  writeExpander(backlightMask);
  write4Bits(0x30);
  delayMs(5);
  write4Bits(0x30);
  ets_delay_us(150);
  write4Bits(0x30);
  write4Bits(0x20);

  command(0x28); // 4-bit, 2 lines, 5x8 font
  command(0x08); // display off
  command(0x01); // clear
  delayMs(2);
  command(0x06); // entry mode: left to right
  command(0x0C); // display on, cursor off, blink off
  lcdReady = true;
}

void LCD1602::clear(void) {
  if (!lcdReady) begin(backlightMask ? 1 : 0);
  if (!lcdReady) return;
  command(0x01);
  delayMs(2);
}

void LCD1602::setBacklight(int on) {
  backlightMask = on ? LCD_BACKLIGHT : 0;
  writeExpander(0);
}

void LCD1602::setCursorInternal(uint8_t row, uint8_t column) {
  static const uint8_t rowOffsets[] = {0x00, 0x40};
  if (row > 1) row = 1;
  if (column > 15) column = 15;
  command(0x80 | (rowOffsets[row] + column));
}

void LCD1602::printText(int row, int column, const char *text) {
  if (!lcdReady) begin(backlightMask ? 1 : 0);
  if (!lcdReady || text == NULL) return;

  uint8_t r = (row <= 1) ? 0 : 1;
  uint8_t c = (column <= 1) ? 0 : (uint8_t)(column - 1);
  if (c > 15) c = 15;
  setCursorInternal(r, c);

  int remaining = 16 - c;
  for (int i = 0; text[i] != '\0' && i < remaining; i++) {
    writeChar((uint8_t)text[i]);
  }
}

void LCD1602::printNumber(int row, int column, double value, int decimals) {
  if (decimals < 0) decimals = 0;
  if (decimals > 3) decimals = 3;
  char buffer[24];
  snprintf(buffer, sizeof(buffer), "%.*f", decimals, value);
  printText(row, column, buffer);
}

#endif
