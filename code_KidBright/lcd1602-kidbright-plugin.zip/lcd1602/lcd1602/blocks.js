var LCD1602_ADDRS = [
  ["0x20", "0x20"], ["0x21", "0x21"], ["0x22", "0x22"], ["0x23", "0x23"],
  ["0x24", "0x24"], ["0x25", "0x25"], ["0x26", "0x26"], ["0x27", "0x27"]
];

Blockly.Blocks['lcd1602_begin'] = {
  init: function() {
    this.appendDummyInput()
      .appendField(Blockly.Msg.LCD1602["LCD 16x2 begin"])
      .appendField(Blockly.Msg.LCD1602["address"])
      .appendField(new Blockly.FieldDropdown(LCD1602_ADDRS), "address")
      .appendField(Blockly.Msg.LCD1602["backlight"])
      .appendField(new Blockly.FieldDropdown([
        [Blockly.Msg.LCD1602["on"], "1"],
        [Blockly.Msg.LCD1602["off"], "0"]
      ]), "backlight");
    this.setPreviousStatement(true, null);
    this.setNextStatement(true, null);
    this.setColour(165);
    this.setTooltip(Blockly.Msg.LCD1602["Initialize LCD"]);
  }
};

Blockly.Blocks['lcd1602_clear'] = {
  init: function() {
    this.appendDummyInput()
      .appendField(Blockly.Msg.LCD1602["LCD clear"])
      .appendField(Blockly.Msg.LCD1602["address"])
      .appendField(new Blockly.FieldDropdown(LCD1602_ADDRS), "address");
    this.setPreviousStatement(true, null);
    this.setNextStatement(true, null);
    this.setColour(165);
    this.setTooltip(Blockly.Msg.LCD1602["Clear LCD screen"]);
  }
};

Blockly.Blocks['lcd1602_backlight'] = {
  init: function() {
    this.appendDummyInput()
      .appendField(Blockly.Msg.LCD1602["LCD backlight"])
      .appendField(Blockly.Msg.LCD1602["address"])
      .appendField(new Blockly.FieldDropdown(LCD1602_ADDRS), "address")
      .appendField(new Blockly.FieldDropdown([
        [Blockly.Msg.LCD1602["on"], "1"],
        [Blockly.Msg.LCD1602["off"], "0"]
      ]), "backlight");
    this.setPreviousStatement(true, null);
    this.setNextStatement(true, null);
    this.setColour(165);
    this.setTooltip(Blockly.Msg.LCD1602["Control LCD backlight"]);
  }
};

Blockly.Blocks['lcd1602_print_text'] = {
  init: function() {
    this.appendDummyInput()
      .appendField(Blockly.Msg.LCD1602["LCD print text"])
      .appendField(Blockly.Msg.LCD1602["address"])
      .appendField(new Blockly.FieldDropdown(LCD1602_ADDRS), "address")
      .appendField(Blockly.Msg.LCD1602["row"])
      .appendField(new Blockly.FieldNumber(1, 1, 2, 1), "row")
      .appendField(Blockly.Msg.LCD1602["column"])
      .appendField(new Blockly.FieldNumber(1, 1, 16, 1), "column")
      .appendField(new Blockly.FieldTextInput("SPACE AVAILABLE"), "text");
    this.setPreviousStatement(true, null);
    this.setNextStatement(true, null);
    this.setColour(165);
    this.setTooltip(Blockly.Msg.LCD1602["Print text on LCD"]);
  }
};

Blockly.Blocks['lcd1602_print_number'] = {
  init: function() {
    this.appendValueInput("value")
      .setCheck("Number")
      .appendField(Blockly.Msg.LCD1602["LCD print number"])
      .appendField(Blockly.Msg.LCD1602["address"])
      .appendField(new Blockly.FieldDropdown(LCD1602_ADDRS), "address")
      .appendField(Blockly.Msg.LCD1602["row"])
      .appendField(new Blockly.FieldNumber(2, 1, 2, 1), "row")
      .appendField(Blockly.Msg.LCD1602["column"])
      .appendField(new Blockly.FieldNumber(1, 1, 16, 1), "column")
      .appendField(Blockly.Msg.LCD1602["decimals"])
      .appendField(new Blockly.FieldNumber(0, 0, 3, 1), "decimals");
    this.setPreviousStatement(true, null);
    this.setNextStatement(true, null);
    this.setColour(165);
    this.setTooltip(Blockly.Msg.LCD1602["Print number on LCD"]);
  }
};
