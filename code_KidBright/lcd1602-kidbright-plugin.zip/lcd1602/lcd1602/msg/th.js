Blockly.Msg.LCD1602 = {
  "LCD 16x2 begin": "เริ่มต้นจอ LCD 16x2",
  "LCD clear": "ล้างหน้าจอ LCD 16x2",
  "LCD backlight": "ไฟพื้นหลัง LCD 16x2",
  "LCD print text": "LCD 16x2 แสดงข้อความ",
  "LCD print number": "LCD 16x2 แสดงตัวเลข",
  "address": "ที่อยู่",
  "row": "บรรทัด",
  "column": "คอลัมน์",
  "decimals": "ทศนิยม",
  "backlight": "ไฟพื้นหลัง",
  "on": "เปิด",
  "off": "ปิด",
  "Initialize LCD": "เริ่มต้นจอ LCD 16x2 แบบ HD44780 ที่ต่อผ่าน PCF8574 I2C",
  "Clear LCD screen": "ล้างข้อความทั้งหมดบนหน้าจอ LCD",
  "Control LCD backlight": "เปิดหรือปิดไฟพื้นหลังของจอ LCD",
  "Print text on LCD": "แสดงข้อความคงที่ในบรรทัดและคอลัมน์ที่กำหนด",
  "Print number on LCD": "แสดงตัวเลขหรือตัวแปรในบรรทัดและคอลัมน์ที่กำหนด"
};
