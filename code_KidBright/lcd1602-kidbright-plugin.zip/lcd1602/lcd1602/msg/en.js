Blockly.Msg.LCD1602 = {
  "LCD 16x2 begin": "LCD 16x2 initialize",
  "LCD clear": "LCD 16x2 clear screen",
  "LCD backlight": "LCD 16x2 backlight",
  "LCD print text": "LCD 16x2 print text",
  "LCD print number": "LCD 16x2 print number",
  "address": "address",
  "row": "row",
  "column": "column",
  "decimals": "decimals",
  "backlight": "backlight",
  "on": "On",
  "off": "Off",
  "Initialize LCD": "Initialize a 16x2 HD44780 LCD with PCF8574 I2C backpack",
  "Clear LCD screen": "Clear the LCD display",
  "Control LCD backlight": "Turn the LCD backlight on or off",
  "Print text on LCD": "Print fixed text at a selected row and column",
  "Print number on LCD": "Print a number or variable at a selected row and column"
};
