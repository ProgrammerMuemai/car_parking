function lcd1602TextLiteral(text) {
  return JSON.stringify(String(text));
}

Blockly.JavaScript['lcd1602_begin'] = function(block) {
  var address = block.getFieldValue('address');
  var backlight = block.getFieldValue('backlight');
  return 'DEV_I2C1.LCD1602(0, ' + address + ').begin(' + backlight + ');\n';
};

Blockly.JavaScript['lcd1602_clear'] = function(block) {
  var address = block.getFieldValue('address');
  return 'DEV_I2C1.LCD1602(0, ' + address + ').clear();\n';
};

Blockly.JavaScript['lcd1602_backlight'] = function(block) {
  var address = block.getFieldValue('address');
  var backlight = block.getFieldValue('backlight');
  return 'DEV_I2C1.LCD1602(0, ' + address + ').setBacklight(' + backlight + ');\n';
};

Blockly.JavaScript['lcd1602_print_text'] = function(block) {
  var address = block.getFieldValue('address');
  var row = block.getFieldValue('row');
  var column = block.getFieldValue('column');
  var text = lcd1602TextLiteral(block.getFieldValue('text'));
  return 'DEV_I2C1.LCD1602(0, ' + address + ').printText(' + row + ', ' + column + ', ' + text + ');\n';
};

Blockly.JavaScript['lcd1602_print_number'] = function(block) {
  var address = block.getFieldValue('address');
  var row = block.getFieldValue('row');
  var column = block.getFieldValue('column');
  var decimals = block.getFieldValue('decimals');
  var value = Blockly.JavaScript.valueToCode(block, 'value', Blockly.JavaScript.ORDER_ATOMIC) || '0';
  return 'DEV_I2C1.LCD1602(0, ' + address + ').printNumber(' + row + ', ' + column + ', ' + value + ', ' + decimals + ');\n';
};
