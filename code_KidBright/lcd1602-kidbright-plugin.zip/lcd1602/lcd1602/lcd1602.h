#ifndef __LCD1602_H__
#define __LCD1602_H__

#include <stdint.h>
#include "driver.h"
#include "device.h"
#include "i2c-dev.h"

class LCD1602 : public Device {
private:
  I2CDev *bus;
  uint8_t backlightMask;
  bool lcdReady;

  bool waitForBus(uint32_t timeoutMs = 1000);
  bool writeExpander(uint8_t value);
  void pulseEnable(uint8_t value);
  void write4Bits(uint8_t value);
  void send(uint8_t value, uint8_t mode);
  void command(uint8_t value);
  void writeChar(uint8_t value);
  void delayMs(uint32_t ms);
  void setCursorInternal(uint8_t row, uint8_t column);

public:
  LCD1602(int bus_ch, int dev_addr);

  void init(void);
  void process(Driver *drv);
  int prop_count(void);
  bool prop_name(int index, char *name);
  bool prop_unit(int index, char *unit);
  bool prop_attr(int index, char *attr);
  bool prop_read(int index, char *value);
  bool prop_write(int index, char *value);

  void begin(int backlightOn = 1);
  void clear(void);
  void setBacklight(int on);
  void printText(int row, int column, const char *text);
  void printNumber(int row, int column, double value, int decimals = 0);
};

#endif
